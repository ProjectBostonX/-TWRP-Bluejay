# PROJECT BLACK — Google Pixel 6a (bluejay)

Independent recovery project scaffold for Google Pixel 6a (`bluejay`, Tensor GS101, arm64). Branding: black / electric blue. This is an independent project, not a TWRP or OrangeFox fork.

**Status: scaffold / preflight only. No bootable recovery image is produced yet.** A real build needs a selected recovery userspace, firmware-matched device configuration, kernel/vendor integration, and device testing.

Pixel 6 family devices use vendor-boot ramdisk components. Recovery packaging must be determined from the exact target firmware; do not guess a recovery partition or flash a generic image.

## Layout
- `.github/workflows/bluejay.yml`: CI preflight
- `scripts/preflight.sh`: target metadata checks
- `device/bluejay/README.md`: device integration checklist
- `docs/SAFETY.md`: safe-development rules
- `branding/README.md`: visual direction

Run **Actions → PROJECT BLACK / bluejay preflight → Run workflow**. This checks metadata only; it does not compile recovery.

References:
- https://source.android.com/docs/setup/build/building-pixel-kernels
- https://github.com/twrpdtgen/android_device_google_bluejay (reference only)
- https://github.com/Evolution-X-Devices/device_google_bluejay (reference only)
