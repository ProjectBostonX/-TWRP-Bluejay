# bluejay device integration notes

Target: Google Pixel 6a  
Codename: `bluejay`  
Platform: Google Tensor GS101  
Architecture: arm64

## Status
Not configured for a recovery build yet.

## Required before implementation
- Identify the exact Android firmware/build targeted.
- Inspect matching boot, init_boot, vendor_boot, dtbo, and vbmeta layout.
- Determine recovery ramdisk integration and image packaging for that firmware.
- Select and pin kernel source/revision and required vendor modules.
- Establish device-specific fstab, init, ueventd, properties, and SELinux policy.
- Verify display, touch, USB, ADB, data decryption, and dynamic-partition behavior.

## vendor_boot warning
Pixel 6 family devices use vendor-boot ramdisk components. The vendor ramdisk must match the installed firmware; a mismatch can cause early boot or SELinux failures. Do not assume a standalone recovery partition exists or flash a generic recovery image.
