#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEVICE_FILE="$ROOT/device/bluejay/README.md"
README="$ROOT/README.md"
fail() { echo "::error::$1" >&2; exit 1; }
[[ -f "$DEVICE_FILE" ]] || fail "Missing device/bluejay/README.md"
[[ -f "$README" ]] || fail "Missing README.md"
grep -qi 'bluejay' "$README" || fail "README does not identify bluejay"
grep -qi 'bluejay' "$DEVICE_FILE" || fail "Device notes do not identify bluejay"
grep -qi 'GS101' "$DEVICE_FILE" || fail "Device notes must identify GS101"
grep -qi 'vendor_boot' "$DEVICE_FILE" || fail "Device notes must document vendor_boot"
echo "Target: Google Pixel 6a / bluejay / GS101 / arm64"
echo "Foundation: independent scaffold"
echo "Build status: NOT CONFIGURED — no recovery image will be produced"
