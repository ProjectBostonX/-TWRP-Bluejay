# Project Black safety rules

1. Never run automatic flashing from CI.
2. Confirm the device codename is `bluejay` before using any image.
3. Record the exact Android build fingerprint and active slot.
4. Keep verified stock firmware and a recovery path available.
5. Back up relevant partitions before modifying them where possible.
6. Match vendor ramdisk and kernel components to the exact firmware target.
7. Determine the intended image destination from the target firmware layout; never guess.
8. Do not issue generic vbmeta, boot, init_boot, or vendor_boot flash instructions.
9. Prefer a temporary boot test only when image format and bootloader support it.
10. Stop if partition layout, firmware compatibility, or image provenance is uncertain.

**Current state:** no flashable Project Black image exists. The workflow only validates metadata.
