# PROJECT BLACK visual identity

- Primary surface: near-black
- Accent: electric blue
- Text: high-contrast white / cool gray
- Tone: minimal, technical, readable
- Project name: PROJECT BLACK

This documents the design direction; no compiled recovery UI or theme assets are included yet.
